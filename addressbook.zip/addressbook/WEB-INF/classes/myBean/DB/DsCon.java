package myBean.DB;

import javax.naming.*;
import java.sql.*;
import javax.sql.DataSource;

public class DsCon {
	private static DataSource ds;

	static {
	    try{
	    	Context initContext = new InitialContext();
			ds = (DataSource) initContext.lookup("java:/comp/env/jdbc/addressbook");
	    }catch (NamingException e) { 
	        throw new ExceptionInInitializerError("'jdbc/addressbook' not found in JNDI");
	    }
	}
	public static Connection getConnection() throws SQLException, NamingException{
		return ds.getConnection();
	}
}
