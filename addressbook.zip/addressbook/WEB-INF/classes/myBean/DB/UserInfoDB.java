package myBean.DB;

import java.sql.*;
import javax.naming.NamingException;
import myBean.DB.DsCon;

public class UserInfoDB {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public UserInfoDB() throws SQLException, NamingException{
		con = DsCon.getConnection();
	}
	public void insertInfo (UserInfo info) throws SQLException{
		String sql = "INSERT INTO info (grp, fname, lname, phone, email, pos, dept, title, bday, addr, homepg, sns, file, memo)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, info.getGrp());
		pstmt.setString(2, info.getFname());
		pstmt.setString(3, info.getLname());
		pstmt.setString(4, info.getPhone());
		pstmt.setString(5, info.getEmail());
		pstmt.setString(6, info.getPos());
		pstmt.setString(7, info.getDept());
		pstmt.setString(8, info.getTitle());
		pstmt.setString(9, info.getBday());
		pstmt.setString(10, info.getAddr());
		pstmt.setString(11, info.getHomepg());
		pstmt.setString(12, info.getSns());
		pstmt.setString(13, info.getFile());
		pstmt.setString(14, info.getMemo());
		pstmt.executeUpdate();
	}
	
	public void updateInfo (UserInfo info) throws SQLException{
		String sql = "UPDATE info SET grp=?, fname=?, lname=?, phone=?, email=?, pos=?, dept=?, title=?, bday=?, addr=?, homepg=?, sns=?, file=?, memo=? WHERE idx=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, info.getGrp());
		pstmt.setString(2, info.getFname());
		pstmt.setString(3, info.getLname());
		pstmt.setString(4, info.getPhone());
		pstmt.setString(5, info.getEmail());
		pstmt.setString(6, info.getPos());
		pstmt.setString(7, info.getDept());
		pstmt.setString(8, info.getTitle());
		pstmt.setString(9, info.getBday());
		pstmt.setString(10, info.getAddr());
		pstmt.setString(11, info.getHomepg());
		pstmt.setString(12, info.getSns());
		pstmt.setString(13, info.getFile());
		pstmt.setString(14, info.getMemo());
		pstmt.setInt(15, info.getIdx());
		pstmt.executeUpdate();
	}
	
	public void updateGrp (String grp, String sgrp) throws SQLException{
		String sql = "UPDATE info SET grp=? WHERE grp=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, sgrp);
		pstmt.setString(2, grp);
		pstmt.executeUpdate();
	}
	
	public void deleteGrp(String grp) throws SQLException{
		String sql = "Delete from info where grp=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, grp);
		pstmt.executeUpdate();
	}
	
	public UserInfo getInfo (int idx) throws SQLException{
		String sql = "SELECT grp, fname, lname, phone, email, pos, dept, title, bday, addr, homepg, sns, file, memo from info where idx=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, idx);
		rs = pstmt.executeQuery();
		rs.next();
		UserInfo user = new UserInfo();
		user.setGrp(rs.getString("grp"));
		user.setFname(rs.getString("fname"));
		user.setLname(rs.getString("lname"));
		user.setPhone(rs.getString("phone"));
		user.setEmail(rs.getString("email"));
		user.setPos(rs.getString("pos"));
		user.setDept(rs.getString("dept"));
		user.setTitle(rs.getString("title"));
		user.setBday(rs.getString("bday"));
		user.setAddr(rs.getString("addr"));
		user.setHomepg(rs.getString("homepg"));
		user.setSns(rs.getString("sns"));
		user.setFile(rs.getString("file"));
		user.setMemo(rs.getString("memo"));
		return user;
	}
	
	public ResultSet getMemInfo (String grp) throws SQLException{
		String sql = "SELECT grp, fname, lname, phone, email, pos, dept, title from info where grp=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, grp);
		rs = pstmt.executeQuery();
		return rs;
	}
	
	
	public void insertTrash (UserInfo info) throws SQLException{
		String sql = "INSERT INTO trash (grp, fname, lname, phone, email, pos, dept, title, bday, addr, homepg, sns, file, memo)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, info.getGrp());
		pstmt.setString(2, info.getFname());
		pstmt.setString(3, info.getLname());
		pstmt.setString(4, info.getPhone());
		pstmt.setString(5, info.getEmail());
		pstmt.setString(6, info.getPos());
		pstmt.setString(7, info.getDept());
		pstmt.setString(8, info.getTitle());
		pstmt.setString(9, info.getBday());
		pstmt.setString(10, info.getAddr());
		pstmt.setString(11, info.getHomepg());
		pstmt.setString(12, info.getSns());
		pstmt.setString(13, info.getFile());
		pstmt.setString(14, info.getMemo());
		pstmt.executeUpdate();
	}
	
	public UserInfo getTrash (int idx) throws SQLException{
		String sql = "SELECT grp, fname, lname, phone, email, pos, dept, title, bday, addr, homepg, sns, file, memo from trash where idx=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, idx);
		rs = pstmt.executeQuery();
		rs.next();
		UserInfo user = new UserInfo();
		user.setGrp(rs.getString("grp"));
		user.setFname(rs.getString("fname"));
		user.setLname(rs.getString("lname"));
		user.setPhone(rs.getString("phone"));
		user.setEmail(rs.getString("email"));
		user.setPos(rs.getString("pos"));
		user.setDept(rs.getString("dept"));
		user.setTitle(rs.getString("title"));
		user.setBday(rs.getString("bday"));
		user.setAddr(rs.getString("addr"));
		user.setHomepg(rs.getString("homepg"));
		user.setSns(rs.getString("sns"));
		user.setFile(rs.getString("file"));
		user.setMemo(rs.getString("memo"));
		return user;
	}
	
	public void deleteInfo(int idx) throws SQLException{
		String sql = "Delete from info where idx=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, idx);
		pstmt.executeUpdate();
	}
	
	public void deleteTrash(int idx) throws SQLException{
		String sql = "Delete from trash where idx=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, idx);
		pstmt.executeUpdate();
	}
	
	public void close() throws SQLException{
		if(rs != null) rs.close();
		if (pstmt != null) pstmt.close();
		if (con != null) con.close();
	}
}
